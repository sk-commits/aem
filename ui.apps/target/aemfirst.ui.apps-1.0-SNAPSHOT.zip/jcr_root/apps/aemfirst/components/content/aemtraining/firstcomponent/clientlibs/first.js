alert(" Jquery is called");
$(document).ready(function(){

 alert(" second alert ");

});
