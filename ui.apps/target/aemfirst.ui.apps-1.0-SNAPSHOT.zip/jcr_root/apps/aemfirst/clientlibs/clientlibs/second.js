alert(" client lib Jquery is called");
$(document).ready(function(){

 alert(" client lib second alert ");

});